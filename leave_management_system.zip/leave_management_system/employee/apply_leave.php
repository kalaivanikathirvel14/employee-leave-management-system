<?php

session_start();

if(!isset($_SESSION['user_id']) || $_SESSION['role']!='employee')
{
    header("Location: ../login.php");
    exit();
}

require '../config/database.php';

$leaveTypes = $conn->query(
"SELECT * FROM leave_types
 WHERE status='active'"
);

?>

<!DOCTYPE html>
<html>
<head>

<title>Apply Leave</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<div class="container mt-4">

<h3>Apply Leave</h3>

<div id="message"></div>

<form id="leaveForm">

<div class="mb-3">

<label>Leave Type</label>

<select name="leave_type_id"
class="form-control"
required>

<option value="">Select</option>

<?php while($leave=$leaveTypes->fetch_assoc()) { ?>

<option value="<?= $leave['id']; ?>">
<?= $leave['leave_name']; ?>
</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label>Start Date</label>

<input
type="date"
name="start_date"
id="start_date"
class="form-control"
required>

</div>

<div class="mb-3">

<label>End Date</label>

<input
type="date"
name="end_date"
id="end_date"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Total Days</label>

<input
type="text"
id="total_days"
class="form-control"
readonly>

</div>

<div class="mb-3">

<label>Reason</label>

<textarea
name="reason"
class="form-control"
required></textarea>

</div>

<button class="btn btn-primary">
Submit
</button>

</form>

</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script>

function calculateDays()
{
    let start = $("#start_date").val();
    let end = $("#end_date").val();

    if(start && end)
    {
        let s = new Date(start);
        let e = new Date(end);

        let diff =
        ((e-s)/(1000*60*60*24))+1;

        if(diff>0)
        {
            $("#total_days").val(diff);
        }
    }
}

$("#start_date,#end_date").on(
"change",
calculateDays
);

$("#leaveForm").submit(function(e){

e.preventDefault();

$.ajax({

url:"save_leave.php",

type:"POST",

data:$(this).serialize(),

success:function(response)
{
    $("#message").html(response);
}

});

});

</script>

</body>
</html>