<?php

session_start();

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'employee')
{
    header("Location: ../login.php");
    exit();
}

require '../config/database.php';

$userId = $_SESSION['user_id'];

if(!isset($_GET['id']))
{
    header("Location: leave_history.php");
    exit();
}

$requestId = (int)$_GET['id'];

/*
|--------------------------------------------------------------------------
| Get Leave Request
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare(
"SELECT *
 FROM leave_requests
 WHERE id = ?
 AND user_id = ?"
);

$stmt->bind_param("ii", $requestId, $userId);
$stmt->execute();

$result = $stmt->get_result();

if($result->num_rows == 0)
{
    die("Invalid Leave Request");
}

$request = $result->fetch_assoc();

/*
|--------------------------------------------------------------------------
| Rule 6
|--------------------------------------------------------------------------
*/

if($request['status'] == 'Approved')
{
    die("
    <div style='padding:20px;color:red;'>
    Approved Leave Requests Cannot Be Edited.
    </div>
    ");
}

/*
|--------------------------------------------------------------------------
| Leave Types
|--------------------------------------------------------------------------
*/

$leaveTypes = $conn->query(
"SELECT *
 FROM leave_types
 WHERE status='active'"
);

$message = "";

/*
|--------------------------------------------------------------------------
| Update Leave
|--------------------------------------------------------------------------
*/

if(isset($_POST['update']))
{
    $leaveTypeId = $_POST['leave_type_id'];
    $startDate   = $_POST['start_date'];
    $endDate     = $_POST['end_date'];
    $reason      = trim($_POST['reason']);

    $today = date('Y-m-d');

    // Rule 1
    if($startDate < $today)
    {
        $message = "<div class='alert alert-danger'>
                    Start Date cannot be earlier than today.
                    </div>";
    }

    // Rule 2
    elseif($endDate < $startDate)
    {
        $message = "<div class='alert alert-danger'>
                    End Date cannot be earlier than Start Date.
                    </div>";
    }

    else
    {
        // Rule 3
        $totalDays =
        (date_diff(
            date_create($startDate),
            date_create($endDate)
        )->days) + 1;

        // Rule 4
        $balanceStmt = $conn->prepare(
        "SELECT remaining_days
         FROM leave_balances
         WHERE user_id=?
         AND leave_type_id=?"
        );

        $balanceStmt->bind_param(
        "ii",
        $userId,
        $leaveTypeId
        );

        $balanceStmt->execute();

        $balance =
        $balanceStmt->get_result()->fetch_assoc();

        if(!$balance ||
           $totalDays > $balance['remaining_days'])
        {
            $message =
            "<div class='alert alert-danger'>
             Insufficient Leave Balance.
             </div>";
        }
        else
        {
            // Rule 5 Overlap Check
            $overlap = $conn->prepare(
            "SELECT id
             FROM leave_requests
             WHERE user_id=?
             AND id != ?
             AND status IN ('Pending','Approved')
             AND (
                    start_date <= ?
                    AND end_date >= ?
                 )"
            );

            $overlap->bind_param(
            "iiss",
            $userId,
            $requestId,
            $endDate,
            $startDate
            );

            $overlap->execute();

            if(
                $overlap->get_result()->num_rows > 0
            )
            {
                $message =
                "<div class='alert alert-danger'>
                 Overlapping Leave Request Exists.
                 </div>";
            }
            else
            {
                $update = $conn->prepare(
                "UPDATE leave_requests
                 SET
                 leave_type_id=?,
                 start_date=?,
                 end_date=?,
                 total_days=?,
                 reason=?,
                 status='Pending'
                 WHERE id=?"
                );

                $update->bind_param(
                "issisi",
                $leaveTypeId,
                $startDate,
                $endDate,
                $totalDays,
                $reason,
                $requestId
                );

                if($update->execute())
                {
                    header(
                    "Location: leave_history.php?updated=1"
                    );
                    exit();
                }
                else
                {
                    $message =
                    "<div class='alert alert-danger'>
                     Failed to update leave.
                     </div>";
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html>
<head>

<title>Edit Leave</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<div class="container mt-4">

<h3>Edit Leave Request</h3>

<?= $message ?>

<form method="POST">

<div class="mb-3">

<label>Leave Type</label>

<select
name="leave_type_id"
class="form-control"
required>

<?php while($leave = $leaveTypes->fetch_assoc()) { ?>

<option
value="<?= $leave['id']; ?>"
<?= ($leave['id'] ==
$request['leave_type_id']) ?
'selected' : ''; ?>>

<?= $leave['leave_name']; ?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label>Start Date</label>

<input
type="date"
name="start_date"
class="form-control"
value="<?= $request['start_date']; ?>"
required>

</div>

<div class="mb-3">

<label>End Date</label>

<input
type="date"
name="end_date"
class="form-control"
value="<?= $request['end_date']; ?>"
required>

</div>

<div class="mb-3">

<label>Reason</label>

<textarea
name="reason"
class="form-control"
required><?= htmlspecialchars($request['reason']); ?></textarea>

</div>

<button
type="submit"
name="update"
class="btn btn-primary">

Update Leave

</button>

<a
href="leave_history.php"
class="btn btn-secondary">

Back

</a>

</form>

</div>

</body>
</html>