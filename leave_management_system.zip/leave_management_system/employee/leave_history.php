<?php

session_start();

if(!isset($_SESSION['user_id']) || $_SESSION['role']!='employee')
{
    header("Location: ../login.php");
    exit();
}

require '../config/database.php';

$userId = $_SESSION['user_id'];

$where = " WHERE lr.user_id = ? ";
$params = [$userId];
$types = "i";

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/

$leaveType = $_GET['leave_type'] ?? '';
$status = $_GET['status'] ?? '';
$fromDate = $_GET['from_date'] ?? '';
$toDate = $_GET['to_date'] ?? '';

if(!empty($leaveType))
{
    $where .= " AND lr.leave_type_id = ? ";
    $params[] = $leaveType;
    $types .= "i";
}

if(!empty($status))
{
    $where .= " AND lr.status = ? ";
    $params[] = $status;
    $types .= "s";
}

if(!empty($fromDate))
{
    $where .= " AND lr.start_date >= ? ";
    $params[] = $fromDate;
    $types .= "s";
}

if(!empty($toDate))
{
    $where .= " AND lr.end_date <= ? ";
    $params[] = $toDate;
    $types .= "s";
}

/*
|--------------------------------------------------------------------------
| Leave Types
|--------------------------------------------------------------------------
*/

$leaveTypes = $conn->query(
"SELECT id, leave_name
 FROM leave_types
 WHERE status='active'"
);

/*
|--------------------------------------------------------------------------
| Leave Requests
|--------------------------------------------------------------------------
*/

$sql = "
SELECT
    lr.id,
    lt.leave_name,
    lr.start_date,
    lr.end_date,
    lr.total_days,
    lr.applied_date,
    lr.status,
    lr.manager_remarks
FROM leave_requests lr
INNER JOIN leave_types lt
ON lt.id = lr.leave_type_id
$where
ORDER BY lr.id DESC
";

$stmt = $conn->prepare($sql);

$stmt->bind_param($types, ...$params);

$stmt->execute();

$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html>
<head>

<title>Leave History</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<div class="container mt-4">

<h3>Leave History</h3>

<!-- FILTER FORM -->

<form method="GET">

<div class="row mb-3">

<div class="col-md-3">

<select
name="leave_type"
class="form-control">

<option value="">
All Leave Types
</option>

<?php while($lt=$leaveTypes->fetch_assoc()) { ?>

<option
value="<?= $lt['id']; ?>"
<?= ($leaveType==$lt['id'])?'selected':'' ?>>

<?= $lt['leave_name']; ?>

</option>

<?php } ?>

</select>

</div>

<div class="col-md-2">

<select
name="status"
class="form-control">

<option value="">All Status</option>

<option value="Pending"
<?= ($status=='Pending')?'selected':'' ?>>
Pending
</option>

<option value="Approved"
<?= ($status=='Approved')?'selected':'' ?>>
Approved
</option>

<option value="Rejected"
<?= ($status=='Rejected')?'selected':'' ?>>
Rejected
</option>

</select>

</div>

<div class="col-md-2">

<input
type="date"
name="from_date"
value="<?= $fromDate ?>"
class="form-control">

</div>

<div class="col-md-2">

<input
type="date"
name="to_date"
value="<?= $toDate ?>"
class="form-control">

</div>

<div class="col-md-3">

<button
type="submit"
class="btn btn-primary">

Filter

</button>

<a
href="leave_history.php"
class="btn btn-secondary">

Reset

</a>

</div>

</div>

</form>

<!-- TABLE -->

<table class="table table-bordered table-striped">

<thead>

<tr>

<th>Request ID</th>
<th>Leave Type</th>
<th>Start Date</th>
<th>End Date</th>
<th>No. Days</th>
<th>Applied Date</th>
<th>Status</th>
<th>Manager Remarks</th>
<th>Action</th>

</tr>

</thead>

<tbody>

<?php if($result->num_rows > 0) { ?>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>

<td><?= $row['id']; ?></td>

<td><?= $row['leave_name']; ?></td>

<td><?= date('d-M-Y',strtotime($row['start_date'])); ?></td>

<td><?= date('d-M-Y',strtotime($row['end_date'])); ?></td>

<td><?= $row['total_days']; ?></td>

<td><?= date('d-M-Y',strtotime($row['applied_date'])); ?></td>

<td>

<?php if($row['status']=='Approved'){ ?>

<span class="badge bg-success">
Approved
</span>

<?php } elseif($row['status']=='Rejected'){ ?>

<span class="badge bg-danger">
Rejected
</span>

<?php } else { ?>

<span class="badge bg-warning text-dark">
Pending
</span>

<?php } ?>

</td>

<td>

<?= !empty($row['manager_remarks'])
? htmlspecialchars($row['manager_remarks'])
: '-' ?>

</td>

<td>

<?php if($row['status']!='Approved'){ ?>

<a
href="edit_leave.php?id=<?= $row['id']; ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<?php } else { ?>

<span class="text-muted">
Locked
</span>

<?php } ?>

</td>

</tr>

<?php } ?>

<?php } else { ?>

<tr>

<td colspan="9" class="text-center">

No Leave Requests Found

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</body>
</html>