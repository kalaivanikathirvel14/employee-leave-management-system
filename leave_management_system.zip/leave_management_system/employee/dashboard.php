<?php

session_start();

if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

if($_SESSION['role'] != 'employee')
{
    header("Location: ../login.php");
    exit();
}

require '../config/database.php';

$userId = $_SESSION['user_id'];

/*
|--------------------------------------------------------------------------
| Dashboard Statistics
|--------------------------------------------------------------------------
*/

// Total Requests
$totalRequests = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests
 WHERE user_id = $userId"
)->fetch_assoc()['total'];

// Approved Requests
$approvedRequests = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests
 WHERE user_id = $userId
 AND status='Approved'"
)->fetch_assoc()['total'];

// Rejected Requests
$rejectedRequests = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests
 WHERE user_id = $userId
 AND status='Rejected'"
)->fetch_assoc()['total'];

// Pending Requests
$pendingRequests = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests
 WHERE user_id = $userId
 AND status='Pending'"
)->fetch_assoc()['total'];

// Available Leave Balance
$leaveBalance = $conn->query(
"SELECT SUM(remaining_days) total_balance
 FROM leave_balances
 WHERE user_id = $userId"
)->fetch_assoc()['total_balance'];

?>

<!DOCTYPE html>
<html>
<head>

<title>Employee Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">

        <span class="navbar-brand">
            Employee Leave Management System
        </span>

        <div>
            <span class="text-white me-3">
                Welcome <?= $_SESSION['name']; ?>
            </span>

            <a href="../logout.php"
               class="btn btn-danger btn-sm">
               Logout
            </a>
        </div>

    </div>
</nav>

<div class="container mt-4">

<h3>Employee Dashboard</h3>

<div class="row mt-4">

    <!-- Total Requests -->
    <div class="col-md-3 mb-3">
        <div class="card bg-primary text-white shadow">
            <div class="card-body text-center">
                <h5>Total Requests</h5>
                <h2><?= $totalRequests; ?></h2>
            </div>
        </div>
    </div>

    <!-- Approved -->
    <div class="col-md-3 mb-3">
        <div class="card bg-success text-white shadow">
            <div class="card-body text-center">
                <h5>Approved</h5>
                <h2><?= $approvedRequests; ?></h2>
            </div>
        </div>
    </div>

    <!-- Pending -->
    <div class="col-md-3 mb-3">
        <div class="card bg-warning text-dark shadow">
            <div class="card-body text-center">
                <h5>Pending</h5>
                <h2><?= $pendingRequests; ?></h2>
            </div>
        </div>
    </div>

    <!-- Rejected -->
    <div class="col-md-3 mb-3">
        <div class="card bg-danger text-white shadow">
            <div class="card-body text-center">
                <h5>Rejected</h5>
                <h2><?= $rejectedRequests; ?></h2>
            </div>
        </div>
    </div>

</div>

<!-- Leave Balance Card -->

<div class="row">

    <div class="col-md-6">

        <div class="card border-success shadow">

            <div class="card-body text-center">

                <h4>Available Leave Balance</h4>

                <h1 class="text-success">
                    <?= $leaveBalance ? $leaveBalance : 0; ?>
                </h1>

                <p>Days Remaining</p>

            </div>

        </div>

    </div>

</div>

<hr>

<div class="mt-4">

    <a href="apply_leave.php"
       class="btn btn-primary">
       Apply Leave
    </a>

    <a href="leave_history.php"
       class="btn btn-secondary">
       Leave History
    </a>

</div>

</div>

</body>
</html>