<?php

session_start();

require '../config/database.php';

$userId = $_SESSION['user_id'];

$leaveTypeId = $_POST['leave_type_id'];
$startDate = $_POST['start_date'];
$endDate = $_POST['end_date'];
$reason = trim($_POST['reason']);

$today = date('Y-m-d');


// Rule 1
if($startDate < $today)
{
    die("<div class='alert alert-danger'>
    Start Date cannot be earlier than today.
    </div>");
}


// Rule 2
if($endDate < $startDate)
{
    die("<div class='alert alert-danger'>
    End Date cannot be earlier than Start Date.
    </div>");
}


// Rule 3
$totalDays =
(date_diff(
date_create($startDate),
date_create($endDate)
)->days)+1;


// Rule 4
$balance = $conn->query(
"SELECT remaining_days
 FROM leave_balances
 WHERE user_id='$userId'
 AND leave_type_id='$leaveTypeId'"
)->fetch_assoc();

if(!$balance)
{
    die("<div class='alert alert-danger'>
    Leave Balance Not Found
    </div>");
}

if($totalDays > $balance['remaining_days'])
{
    die("<div class='alert alert-danger'>
    Insufficient Leave Balance
    </div>");
}


// Rule 5
$overlap = $conn->query(
"SELECT id
 FROM leave_requests
 WHERE user_id='$userId'
 AND status IN ('Pending','Approved')
 AND (
        start_date <= '$endDate'
        AND
        end_date >= '$startDate'
     )"
);

if($overlap->num_rows > 0)
{
    die("<div class='alert alert-danger'>
    Overlapping Leave Request Exists
    </div>");
}


// Save Leave Request

$stmt = $conn->prepare(
"INSERT INTO leave_requests
(
user_id,
leave_type_id,
start_date,
end_date,
total_days,
reason,
status
)
VALUES
(?,?,?,?,?,?,'Pending')
");

$stmt->bind_param(
"iissis",
$userId,
$leaveTypeId,
$startDate,
$endDate,
$totalDays,
$reason
);

if($stmt->execute())
{
    echo "
    <div class='alert alert-success'>
    Leave Request Submitted Successfully
    </div>";
}
else
{
    echo "
    <div class='alert alert-danger'>
    Failed To Submit Leave Request
    </div>";
}