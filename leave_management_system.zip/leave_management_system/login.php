<?php

session_start();

require 'config/database.php';

$error = "";

if($_SERVER['REQUEST_METHOD']=="POST")
{
    $login    = trim($_POST['login']);
    $password = trim($_POST['password']);

    $sql = "SELECT * FROM users
            WHERE (username=? OR email=?)
            AND status='active'
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss",$login,$login);
    $stmt->execute();

    $result = $stmt->get_result();

    if($result->num_rows > 0)
    {
        $user = $result->fetch_assoc();

        if(password_verify($password,$user['password']))
        {
            session_regenerate_id(true);

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role']    = $user['role'];
            $_SESSION['name']    = $user['name'];

            if($user['role']=="admin"){
                header("Location: admin/dashboard.php");
            }
            elseif($user['role']=="manager"){
                header("Location: manager/dashboard.php");
            }
            else{
                header("Location: employee/dashboard.php");
            }

            exit();
        }
        else{
            $error = "Invalid password";
        }
    }
    else{
        $error = "User not found";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container">

<div class="row justify-content-center mt-5">

<div class="col-md-4">

<div class="card shadow">

<div class="card-header text-center">
<h4>Employee Leave Management</h4>
</div>

<div class="card-body">

<?php if(!empty($error)){ ?>

<div class="alert alert-danger">
<?php echo $error; ?>
</div>

<?php } ?>

<form method="POST">

<div class="mb-3">
<label>Username / Email</label>
<input
type="text"
name="login"
class="form-control"
required>
</div>

<div class="mb-3">
<label>Password</label>
<input
type="password"
name="password"
class="form-control"
required>
</div>

<button
type="submit"
class="btn btn-primary w-100">
Login
</button>

</form>

</div>

</div>

</div>

</div>

</div>

</body>
</html>