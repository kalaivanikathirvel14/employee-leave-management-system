<?php

require '../config/database.php';
require 'auth.php';

$id = $_GET['id'];

$result = $conn->query(
"SELECT * FROM leave_types
 WHERE id='$id'"
);

$data = $result->fetch_assoc();

if(isset($_POST['update']))
{
    $leave_name = trim($_POST['leave_name']);
    $annual_quota = trim($_POST['annual_quota']);
    $status = trim($_POST['status']);

    $sql = $conn->prepare(
    "UPDATE leave_types
     SET
     leave_name=?,
     annual_quota=?,
     status=?
     WHERE id=?"
    );

    $sql->bind_param(
    "sisi",
    $leave_name,
    $annual_quota,
    $status,
    $id
    );

    $sql->execute();

    header("Location: leave_types.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>

<title>Edit Leave Type</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<div class="container mt-4">

<h3>Edit Leave Configuration</h3>

<form method="POST">

<div class="mb-3">

<label>Leave Type</label>

<input
type="text"
name="leave_name"
class="form-control"
value="<?= $data['leave_name']; ?>"
required>

</div>

<div class="mb-3">

<label>Annual Quota</label>

<input
type="number"
name="annual_quota"
class="form-control"
value="<?= $data['annual_quota']; ?>"
required>

</div>

<div class="mb-3">

<label>Status</label>

<select
name="status"
class="form-control">

<option
value="active"
<?= $data['status']=='active'?'selected':'' ?>>
Active
</option>

<option
value="inactive"
<?= $data['status']=='inactive'?'selected':'' ?>>
Inactive
</option>

</select>

</div>

<button
type="submit"
name="update"
class="btn btn-primary">

Update

</button>

<a
href="leave_types.php"
class="btn btn-secondary">

Back

</a>

</form>

</div>

</body>
</html>