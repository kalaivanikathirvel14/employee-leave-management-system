<?php

require '../config/database.php';
require 'auth.php';

$msg = "";

if(isset($_POST['save']))
{
    $employee_id = trim($_POST['employee_id']);
    $name        = trim($_POST['name']);
    $email       = trim($_POST['email']);
    $mobile      = trim($_POST['mobile']);
    $department  = trim($_POST['department']);
    $designation = trim($_POST['designation']);
    $role        = trim($_POST['role']);
    $status      = trim($_POST['status']);

    $password = password_hash("Password@123", PASSWORD_DEFAULT);
    $username = strtolower($employee_id);

    // Check duplicate employee/email
    $check = $conn->prepare(
        "SELECT id FROM users
         WHERE email = ? OR employee_id = ?"
    );

    $check->bind_param("ss", $email, $employee_id);
    $check->execute();
    $result = $check->get_result();

    if($result->num_rows > 0)
    {
        $msg = "Employee already exists";
    }
    else
    {
        $sql = $conn->prepare(
            "INSERT INTO users
            (
                employee_id,
                name,
                username,
                email,
                password,
                mobile,
                department,
                designation,
                role,
                status
            )
            VALUES
            (?,?,?,?,?,?,?,?,?,?)"
        );

        $sql->bind_param(
            "ssssssssss",
            $employee_id,
            $name,
            $username,
            $email,
            $password,
            $mobile,
            $department,
            $designation,
            $role,
            $status
        );

        if($sql->execute())
        {
            // New user ID
            $newUserId = $conn->insert_id;

            // Create default leave balances
            $leaveTypes = $conn->query(
                "SELECT * FROM leave_types
                 WHERE status='active'"
            );

            while($leave = $leaveTypes->fetch_assoc())
            {
                $quota = $leave['annual_quota'];

                $insertBalance = $conn->prepare(
                    "INSERT INTO leave_balances
                    (
                        user_id,
                        leave_type_id,
                        allocated_days,
                        used_days,
                        remaining_days
                    )
                    VALUES
                    (?,?,?,?,?)"
                );

                $usedDays = 0;

                $insertBalance->bind_param(
                    "iiiii",
                    $newUserId,
                    $leave['id'],
                    $quota,
                    $usedDays,
                    $quota
                );

                $insertBalance->execute();
            }

            $msg = "User Created Successfully";
        }
        else
        {
            $msg = "Error : " . $conn->error;
        }
    }
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Create User</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="container mt-4">

<h3>Create User</h3>

<?php if($msg!=""){ ?>
<div class="alert alert-info">
<?php echo $msg; ?>
</div>
<?php } ?>

<form method="POST">

<div class="row">

<div class="col-md-6 mb-3">
<label>Employee ID</label>
<input type="text" name="employee_id" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Employee Name</label>
<input type="text" name="name" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Email</label>
<input type="email" name="email" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Mobile</label>
<input type="text" name="mobile" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Department</label>
<input type="text" name="department" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Designation</label>
<input type="text" name="designation" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Role</label>
<select name="role" class="form-control" required>
<option value="employee">Employee</option>
<option value="manager">Manager</option>
<option value="admin">Admin</option>
</select>
</div>

<div class="col-md-6 mb-3">
<label>Status</label>
<select name="status" class="form-control">
<option value="active">Active</option>
<option value="inactive">Inactive</option>
</select>
</div>

</div>

<button class="btn btn-primary" name="save">
Create User
</button>

</form>

</div>

</body>
</html>