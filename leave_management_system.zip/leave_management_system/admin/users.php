<?php

require '../config/database.php';
require 'auth.php';

$where = "1=1";

if(isset($_GET['search']))
{
    $search = trim($_GET['search']);

    $where .= " AND
    (
    name LIKE '%$search%'
    OR employee_id LIKE '%$search%'
    OR department LIKE '%$search%'
    )";
}

$users = $conn->query(
"SELECT * FROM users
 WHERE $where
 ORDER BY id DESC"
);

?>

<!DOCTYPE html>
<html>
<head>
<title>Users</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<div class="container mt-4">

<h3>User Management</h3>

<form method="GET">

<div class="row mb-3">

<div class="col-md-4">
<input
type="text"
name="search"
class="form-control"
placeholder="Name / Employee ID / Department">
</div>

<div class="col-md-2">
<button class="btn btn-primary">
Search
</button>
</div>

</div>

</form>

<a href="create_user.php" class="btn btn-success mb-3">
Create User
</a>

<table class="table table-bordered">

<tr>
<th>ID</th>
<th>Emp ID</th>
<th>Name</th>
<th>Email</th>
<th>Department</th>
<th>Role</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($row=$users->fetch_assoc()) { ?>

<tr>

<td><?= $row['id']; ?></td>
<td><?= $row['employee_id']; ?></td>
<td><?= $row['name']; ?></td>
<td><?= $row['email']; ?></td>
<td><?= $row['department']; ?></td>
<td><?= $row['role']; ?></td>
<td><?= $row['status']; ?></td>

<td>

<a
href="edit_user.php?id=<?= $row['id']; ?>"
class="btn btn-warning btn-sm">
Edit
</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>