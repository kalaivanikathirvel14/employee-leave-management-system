<?php

require '../config/database.php';
require 'auth.php';

$leaveTypes = $conn->query(
"SELECT * FROM leave_types
 ORDER BY id ASC"
);

?>

<!DOCTYPE html>
<html>
<head>

<title>Leave Configuration</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<div class="container mt-4">

<h3>Leave Configuration</h3>

<table class="table table-bordered">

<thead>

<tr>
<th>ID</th>
<th>Leave Type</th>
<th>Annual Quota</th>
<th>Status</th>
<th>Action</th>
</tr>

</thead>

<tbody>

<?php while($row=$leaveTypes->fetch_assoc()) { ?>

<tr>

<td><?= $row['id']; ?></td>

<td><?= $row['leave_name']; ?></td>

<td><?= $row['annual_quota']; ?></td>

<td><?= ucfirst($row['status']); ?></td>

<td>

<a
href="edit_leave_type.php?id=<?= $row['id']; ?>"
class="btn btn-warning btn-sm">

Edit

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</body>
</html>