<?php

session_start();

if(!isset($_SESSION['user_id']) || $_SESSION['role']!='admin')
{
    header("Location: ../login.php");
    exit();
}

require '../config/database.php';

/* Employee Stats */

$totalEmployees = $conn->query(
"SELECT COUNT(*) total
 FROM users
 WHERE role='employee'"
)->fetch_assoc()['total'];

$activeEmployees = $conn->query(
"SELECT COUNT(*) total
 FROM users
 WHERE role='employee'
 AND status='active'"
)->fetch_assoc()['total'];

$inactiveEmployees = $conn->query(
"SELECT COUNT(*) total
 FROM users
 WHERE role='employee'
 AND status='inactive'"
)->fetch_assoc()['total'];

/* Leave Stats */

$totalRequests = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests"
)->fetch_assoc()['total'];

$approvedLeaves = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests
 WHERE status='Approved'"
)->fetch_assoc()['total'];

$rejectedLeaves = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests
 WHERE status='Rejected'"
)->fetch_assoc()['total'];

$pendingLeaves = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests
 WHERE status='Pending'"
)->fetch_assoc()['total'];

?>

<!DOCTYPE html>
<html>
<head>

<title>Admin Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>

<body>

<div class="container mt-4">

<h3>Admin Dashboard</h3>

<div class="row">

<div class="col-md-3 mb-3">
<div class="card bg-primary text-white">
<div class="card-body text-center">
<h5>Total Employees</h5>
<h2><?= $totalEmployees ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-success text-white">
<div class="card-body text-center">
<h5>Active Employees</h5>
<h2><?= $activeEmployees ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-danger text-white">
<div class="card-body text-center">
<h5>Inactive Employees</h5>
<h2><?= $inactiveEmployees ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-dark text-white">
<div class="card-body text-center">
<h5>Total Requests</h5>
<h2><?= $totalRequests ?></h2>
</div>
</div>
</div>

</div>

<div class="row">

<div class="col-md-4 mb-3">
<div class="card bg-success text-white">
<div class="card-body text-center">
<h5>Approved Leaves</h5>
<h2><?= $approvedLeaves ?></h2>
</div>
</div>
</div>

<div class="col-md-4 mb-3">
<div class="card bg-danger text-white">
<div class="card-body text-center">
<h5>Rejected Leaves</h5>
<h2><?= $rejectedLeaves ?></h2>
</div>
</div>
</div>

<div class="col-md-4 mb-3">
<div class="card bg-warning">
<div class="card-body text-center">
<h5>Pending Approvals</h5>
<h2><?= $pendingLeaves ?></h2>
</div>
</div>
</div>

</div>

<div class="card mt-4">

<div class="card-header">
Leave Request Statistics
</div>

<div class="card-body">

<canvas id="leaveChart"></canvas>

</div>

</div>

<br>

<a href="users.php"
class="btn btn-primary">
User Management
</a>

<a href="leave_types.php"
class="btn btn-success">
Leave Configuration
</a>

<a href="reports.php"
class="btn btn-dark">
Reports
</a>

</div>

<script>

const ctx =
document.getElementById('leaveChart');

new Chart(ctx, {

type: 'bar',

data: {

labels: [
'Approved',
'Rejected',
'Pending'
],

datasets: [{

label: 'Leave Requests',

data: [
<?= $approvedLeaves ?>,
<?= $rejectedLeaves ?>,
<?= $pendingLeaves ?>
],

borderWidth: 1

}]

},

options: {

responsive: true,

scales: {

y: {
beginAtZero: true
}

}

}

});

</script>

</body>
</html>