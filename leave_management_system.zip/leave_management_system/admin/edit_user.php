<?php

require '../config/database.php';
require 'auth.php';

$id = $_GET['id'];

$user = $conn->query(
"SELECT * FROM users WHERE id='$id'"
)->fetch_assoc();

if(isset($_POST['update']))
{
    $name        = $_POST['name'];
    $email       = $_POST['email'];
    $mobile      = $_POST['mobile'];
    $department  = $_POST['department'];
    $designation = $_POST['designation'];
    $role        = $_POST['role'];
    $status      = $_POST['status'];

    $sql = $conn->prepare(
    "UPDATE users SET
    name=?,
    email=?,
    mobile=?,
    department=?,
    designation=?,
    role=?,
    status=?
    WHERE id=?"
    );

    $sql->bind_param(
    "sssssssi",
    $name,
    $email,
    $mobile,
    $department,
    $designation,
    $role,
    $status,
    $id
    );

    $sql->execute();

    header("Location: users.php");
}

?>

<form method="POST">

<input
type="text"
name="name"
value="<?= $user['name']; ?>">

<input
type="email"
name="email"
value="<?= $user['email']; ?>">

<input
type="text"
name="mobile"
value="<?= $user['mobile']; ?>">

<input
type="text"
name="department"
value="<?= $user['department']; ?>">

<input
type="text"
name="designation"
value="<?= $user['designation']; ?>">

<select name="role">
<option <?= $user['role']=='employee'?'selected':'' ?>>
employee
</option>
<option <?= $user['role']=='manager'?'selected':'' ?>>
manager
</option>
<option <?= $user['role']=='admin'?'selected':'' ?>>
admin
</option>
</select>

<select name="status">
<option value="active">Active</option>
<option value="inactive">Inactive</option>
</select>

<button name="update">
Update
</button>

</form>