<?php

session_start();

if(!isset($_SESSION['user_id']) || $_SESSION['role']!='admin')
{
    header("Location: ../login.php");
    exit();
}

require '../config/database.php';

$where = " WHERE 1=1 ";

if(!empty($_GET['employee_name']))
{
    $employeeName = $conn->real_escape_string($_GET['employee_name']);
    $where .= " AND u.name LIKE '%$employeeName%' ";
}

if(!empty($_GET['department']))
{
    $department = $conn->real_escape_string($_GET['department']);
    $where .= " AND u.department='$department' ";
}

if(!empty($_GET['leave_type']))
{
    $leaveType = (int)$_GET['leave_type'];
    $where .= " AND lt.id='$leaveType' ";
}

if(!empty($_GET['status']))
{
    $status = $conn->real_escape_string($_GET['status']);
    $where .= " AND lr.status='$status' ";
}

if(!empty($_GET['from_date']))
{
    $fromDate = $_GET['from_date'];
    $where .= " AND lr.start_date >= '$fromDate' ";
}

if(!empty($_GET['to_date']))
{
    $toDate = $_GET['to_date'];
    $where .= " AND lr.end_date <= '$toDate' ";
}

$leaveTypes = $conn->query(
"SELECT * FROM leave_types
 WHERE status='active'"
);

$sql = "

SELECT

u.name AS employee_name,
u.employee_id,
u.department,

lt.leave_name,

lr.start_date,
lr.end_date,
lr.total_days,

lr.status,

m.name AS approved_by_name,

lr.approval_date

FROM leave_requests lr

INNER JOIN users u
ON u.id = lr.user_id

INNER JOIN leave_types lt
ON lt.id = lr.leave_type_id

LEFT JOIN users m
ON m.id = lr.approved_by

$where

ORDER BY lr.id DESC

";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>

<title>Leave Reports</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<div class="container mt-4">

<h3>Leave Reports</h3>

<form method="GET">

<div class="row">

<div class="col-md-2">

<input
type="text"
name="employee_name"
class="form-control"
placeholder="Employee Name"
value="<?= $_GET['employee_name'] ?? '' ?>">

</div>

<div class="col-md-2">

<input
type="text"
name="department"
class="form-control"
placeholder="Department"
value="<?= $_GET['department'] ?? '' ?>">

</div>

<div class="col-md-2">

<select
name="leave_type"
class="form-control">

<option value="">All Types</option>

<?php while($lt=$leaveTypes->fetch_assoc()) { ?>

<option
value="<?= $lt['id']; ?>">

<?= $lt['leave_name']; ?>

</option>

<?php } ?>

</select>

</div>

<div class="col-md-2">

<select
name="status"
class="form-control">

<option value="">All Status</option>

<option value="Pending">Pending</option>
<option value="Approved">Approved</option>
<option value="Rejected">Rejected</option>

</select>

</div>

<div class="col-md-2">

<input
type="date"
name="from_date"
class="form-control">

</div>

<div class="col-md-2">

<input
type="date"
name="to_date"
class="form-control">

</div>

</div>

<br>

<button
type="submit"
class="btn btn-primary">

Generate Report

</button>

<a
href="reports.php"
class="btn btn-secondary">

Reset

</a>

</form>

<hr>

<table class="table table-bordered table-striped">

<thead>

<tr>

<th>Employee Name</th>
<th>Employee ID</th>
<th>Department</th>
<th>Leave Type</th>
<th>Start Date</th>
<th>End Date</th>
<th>Days</th>
<th>Status</th>
<th>Approved By</th>
<th>Approval Date</th>

</tr>

</thead>

<tbody>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>

<td><?= htmlspecialchars($row['employee_name']); ?></td>

<td><?= $row['employee_id']; ?></td>

<td><?= $row['department']; ?></td>

<td><?= $row['leave_name']; ?></td>

<td><?= $row['start_date']; ?></td>

<td><?= $row['end_date']; ?></td>

<td><?= $row['total_days']; ?></td>

<td><?= $row['status']; ?></td>

<td>
<?= $row['approved_by_name'] ?? '-' ?>
</td>

<td>
<?= $row['approval_date'] ?? '-' ?>
</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</body>
</html>