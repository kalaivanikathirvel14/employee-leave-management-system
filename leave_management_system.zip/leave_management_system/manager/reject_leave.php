<?php

session_start();

if($_SESSION['role']!='manager')
{
    exit();
}

require '../config/database.php';

$id = (int)$_GET['id'];

$message = "";

if(isset($_POST['reject']))
{
    $remarks = trim($_POST['remarks']);

    if(empty($remarks))
    {
        $message =
        "<div class='alert alert-danger'>
        Manager Remarks Required
        </div>";
    }
    else
    {
        $stmt = $conn->prepare(

        "UPDATE leave_requests

        SET

        status='Rejected',
        manager_remarks=?

        WHERE id=?"

        );

        $stmt->bind_param(
        "si",
        $remarks,
        $id
        );

        $stmt->execute();

        header(
        "Location: leave_requests.php"
        );

        exit();
    }
}

?>

<!DOCTYPE html>
<html>
<head>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<div class="container mt-4">

<h3>Reject Leave Request</h3>

<?= $message ?>

<form method="POST">

<div class="mb-3">

<label>Manager Remarks</label>

<textarea
name="remarks"
class="form-control"
required></textarea>

</div>

<button
type="submit"
name="reject"
class="btn btn-danger">

Reject Leave

</button>

<a
href="leave_requests.php"
class="btn btn-secondary">

Back

</a>

</form>

</div>

</body>
</html>