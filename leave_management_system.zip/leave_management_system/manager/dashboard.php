<?php

session_start();

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'manager')
{
    header("Location: ../login.php");
    exit();
}

require '../config/database.php';

/*
|--------------------------------------------------------------------------
| Dashboard Statistics
|--------------------------------------------------------------------------
*/

$totalRequests = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests"
)->fetch_assoc()['total'];

$pendingRequests = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests
 WHERE status='Pending'"
)->fetch_assoc()['total'];

$approvedRequests = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests
 WHERE status='Approved'"
)->fetch_assoc()['total'];

$rejectedRequests = $conn->query(
"SELECT COUNT(*) total
 FROM leave_requests
 WHERE status='Rejected'"
)->fetch_assoc()['total'];

?>

<!DOCTYPE html>
<html>
<head>

<title>Manager Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">

        <span class="navbar-brand">
            Employee Leave Management System
        </span>

        <div>
            <span class="text-white me-3">
                Welcome <?= htmlspecialchars($_SESSION['name']); ?>
            </span>

            <a href="../logout.php"
               class="btn btn-danger btn-sm">
               Logout
            </a>
        </div>

    </div>
</nav>

<div class="container mt-4">

<h3>Manager Dashboard</h3>

<div class="row mt-4">

    <!-- Total Requests -->
    <div class="col-md-3 mb-3">
        <div class="card bg-primary text-white shadow">
            <div class="card-body text-center">
                <h5>Total Requests</h5>
                <h2><?= $totalRequests; ?></h2>
            </div>
        </div>
    </div>

    <!-- Pending -->
    <div class="col-md-3 mb-3">
        <div class="card bg-warning text-dark shadow">
            <div class="card-body text-center">
                <h5>Pending Requests</h5>
                <h2><?= $pendingRequests; ?></h2>
            </div>
        </div>
    </div>

    <!-- Approved -->
    <div class="col-md-3 mb-3">
        <div class="card bg-success text-white shadow">
            <div class="card-body text-center">
                <h5>Approved Requests</h5>
                <h2><?= $approvedRequests; ?></h2>
            </div>
        </div>
    </div>

    <!-- Rejected -->
    <div class="col-md-3 mb-3">
        <div class="card bg-danger text-white shadow">
            <div class="card-body text-center">
                <h5>Rejected Requests</h5>
                <h2><?= $rejectedRequests; ?></h2>
            </div>
        </div>
    </div>

</div>

<div class="mt-4">

    <a href="leave_requests.php"
       class="btn btn-primary">
       Manage Leave Requests
    </a>

</div>

</div>

</body>
</html>