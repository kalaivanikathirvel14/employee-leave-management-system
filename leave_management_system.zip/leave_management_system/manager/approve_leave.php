<?php

session_start();

if($_SESSION['role']!='manager')
{
    exit();
}

require '../config/database.php';

$id = (int)$_GET['id'];

$conn->begin_transaction();

try
{

$request = $conn->query(

"SELECT *
 FROM leave_requests
 WHERE id='$id'

 FOR UPDATE"

)->fetch_assoc();

if(!$request)
{
    throw new Exception("Request not found");
}

if($request['status']!='Pending')
{
    throw new Exception("Already processed");
}

/*
|--------------------------------------------------------------------------
| Reduce Balance
|--------------------------------------------------------------------------
*/

$conn->query(

"UPDATE leave_balances

SET

used_days =
used_days + {$request['total_days']},

remaining_days =
remaining_days - {$request['total_days']}

WHERE

user_id = {$request['user_id']}
AND
leave_type_id =
{$request['leave_type_id']}"

);

/*
|--------------------------------------------------------------------------
| Approve Request
|--------------------------------------------------------------------------
*/

$conn->query(

"UPDATE leave_requests

SET

status='Approved',
manager_remarks='Approved'

WHERE id='$id'"

);

$conn->commit();

header("Location: leave_requests.php");

}
catch(Exception $e)
{
    $conn->rollback();

    echo $e->getMessage();
}