<?php

session_start();

if(!isset($_SESSION['user_id']) || $_SESSION['role']!='manager')
{
    header("Location: ../login.php");
    exit();
}

require '../config/database.php';

$result = $conn->query(

"SELECT

lr.id,
u.employee_id,
u.name,
u.department,
lt.leave_name,

lr.start_date,
lr.end_date,
lr.total_days,

lr.reason,
lr.status

FROM leave_requests lr

INNER JOIN users u
ON u.id = lr.user_id

INNER JOIN leave_types lt
ON lt.id = lr.leave_type_id

ORDER BY lr.id DESC"

);

?>

<!DOCTYPE html>
<html>
<head>

<title>Leave Approval</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<div class="container mt-4">

<h3>Leave Approval Module</h3>

<table class="table table-bordered">

<thead>

<tr>

<th>Employee Name</th>
<th>Employee ID</th>
<th>Department</th>
<th>Leave Type</th>
<th>Start Date</th>
<th>End Date</th>
<th>Days</th>
<th>Reason</th>
<th>Status</th>
<th>Action</th>

</tr>

</thead>

<tbody>

<?php while($row=$result->fetch_assoc()) { ?>

<tr>

<td><?= $row['name']; ?></td>
<td><?= $row['employee_id']; ?></td>
<td><?= $row['department']; ?></td>

<td><?= $row['leave_name']; ?></td>

<td><?= $row['start_date']; ?></td>
<td><?= $row['end_date']; ?></td>

<td><?= $row['total_days']; ?></td>

<td><?= htmlspecialchars($row['reason']); ?></td>

<td><?= $row['status']; ?></td>

<td>

<?php if($row['status']=='Pending') { ?>

<a
href="approve_leave.php?id=<?= $row['id']; ?>"
class="btn btn-success btn-sm">

Approve

</a>

<a
href="reject_leave.php?id=<?= $row['id']; ?>"
class="btn btn-danger btn-sm">

Reject

</a>

<?php } ?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</body>
</html>