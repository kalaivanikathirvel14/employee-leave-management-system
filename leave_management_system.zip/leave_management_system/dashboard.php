<?php

session_start();

if(!isset($_SESSION['user_id']))
{
    header("Location: login.php");
    exit();
}

require 'config/database.php';

$userId = $_SESSION['user_id'];
$role   = $_SESSION['role'];
$name   = $_SESSION['name'];

?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
</head>

<body>

<nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">

        <span class="navbar-brand">
            Employee Leave Management System
        </span>

        <div>
            <span class="text-white me-3">
                Welcome, <?= htmlspecialchars($name); ?>
            </span>

            <a href="logout.php" class="btn btn-danger btn-sm">
                Logout
            </a>
        </div>

    </div>
</nav>

<div class="container mt-4">

<?php

/*
|--------------------------------------------------------------------------
| ADMIN DASHBOARD
|--------------------------------------------------------------------------
*/

if($role == 'admin')
{
    $totalEmployees = $conn->query(
        "SELECT COUNT(*) total FROM users WHERE role='employee'"
    )->fetch_assoc()['total'];

    $activeEmployees = $conn->query(
        "SELECT COUNT(*) total FROM users
         WHERE role='employee'
         AND status='active'"
    )->fetch_assoc()['total'];

    $inactiveEmployees = $conn->query(
        "SELECT COUNT(*) total FROM users
         WHERE role='employee'
         AND status='inactive'"
    )->fetch_assoc()['total'];

?>

<h3>Admin Dashboard</h3>

<div class="row mt-4">

    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h5>Total Employees</h5>
                <h2><?= $totalEmployees ?></h2>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h5>Active Employees</h5>
                <h2><?= $activeEmployees ?></h2>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card bg-danger text-white">
            <div class="card-body">
                <h5>Inactive Employees</h5>
                <h2><?= $inactiveEmployees ?></h2>
            </div>
        </div>
    </div>

</div>

<div class="mt-4">

    <a href="admin/users.php"
       class="btn btn-primary">
        User Management
    </a>

    <a href="admin/leave_types.php"
       class="btn btn-success">
        Leave Configuration
    </a>

</div>

<?php
}

/*
|--------------------------------------------------------------------------
| MANAGER DASHBOARD
|--------------------------------------------------------------------------
*/

elseif($role == 'manager')
{
?>

<h3>Manager Dashboard</h3>

<div class="alert alert-info">
    Welcome Manager <?= htmlspecialchars($name); ?>
</div>

<a href="manager/leave_requests.php"
   class="btn btn-primary">
   Leave Approvals
</a>

<?php
}

/*
|--------------------------------------------------------------------------
| EMPLOYEE DASHBOARD
|--------------------------------------------------------------------------
*/

elseif($role == 'employee')
{
?>

<h3>Employee Dashboard</h3>

<div class="alert alert-success">
    Welcome <?= htmlspecialchars($name); ?>
</div>

<a href="employee/apply_leave.php"
   class="btn btn-primary">
   Apply Leave
</a>

<a href="employee/leave_history.php"
   class="btn btn-secondary">
   Leave History
</a>

<?php
}
?>

</div>

</body>
</html>